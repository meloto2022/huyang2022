#!/usr/bin/env python3
"""
智能家居报价单生成器
使用ReportLab生成专业的PDF报价单
"""

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm, mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from datetime import datetime, timedelta
import os

# 中文字体设置（如果系统中没有中文字体，需要下载并指定）
# 这里使用Windows自带的中文字体
def register_fonts():
    """注册中文字体"""
    try:
        # Windows系统中文字体
        pdfmetrics.registerFont(TTFont('SimSun', 'C:/Windows/Fonts/simsun.ttc', subfontIndex=0))
        pdfmetrics.registerFont(TTFont('SimHei', 'C:/Windows/Fonts/simhei.ttf'))
        return True
    except:
        # 如果Windows字体不可用，尝试其他字体
        try:
            pdfmetrics.registerFont(TTFont('SimSun', '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'))
            return True
        except:
            print("警告：无法加载中文字体，PDF中的中文可能无法正常显示")
            return False

# 定义样式
def get_styles():
    """获取文档样式"""
    styles = getSampleStyleSheet()

    # 标题样式
    styles.add(ParagraphStyle(
        name='Title',
        fontName='SimHei',
        fontSize=24,
        textColor=colors.HexColor('#1a5490'),
        spaceAfter=20,
        alignment=TA_CENTER,
        bold=True
    ))

    # 小标题样式
    styles.add(ParagraphStyle(
        name='SectionTitle',
        fontName='SimHei',
        fontSize=14,
        textColor=colors.HexColor('#1a5490'),
        spaceBefore=12,
        spaceAfter=8,
        bold=True
    ))

    # 正文字体
    styles.add(ParagraphStyle(
        name='BodyText',
        fontName='SimSun',
        fontSize=10,
        spaceAfter=6,
        leading=14
    ))

    # 表头字体
    styles.add(ParagraphStyle(
        name='TableHeader',
        fontName='SimHei',
        fontSize=10,
        textColor=colors.white,
        alignment=TA_CENTER
    ))

    return styles

class SmartHomeQuotation:
    """智能家居报价单生成器"""

    def __init__(self, output_path='quotation.pdf'):
        """初始化报价单"""
        self.output_path = output_path
        self.doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=2*cm,
            bottomMargin=2*cm
        )
        self.story = []
        self.styles = get_styles()

        # 公司信息（可自定义）
        self.company_info = {
            'name': '智能家居科技有限公司',
            'phone': '400-XXX-XXXX',
            'wechat': 'smart-home-xxx',
            'address': 'XX市XX区XX路XX号',
        }

        # 客户信息
        self.customer_info = {
            'name': '',
            'phone': '',
            'address': '',
            'area': '',
        }

        # 项目信息
        self.project_info = {
            'rooms': {},
            'functions': [],
        }

        # 产品清单
        self.products = []

    def set_company_info(self, name, phone, address, wechat=''):
        """设置公司信息"""
        self.company_info = {
            'name': name,
            'phone': phone,
            'wechat': wechat,
            'address': address,
        }

    def set_customer_info(self, name, phone, address, area=''):
        """设置客户信息"""
        self.customer_info = {
            'name': name,
            'phone': phone,
            'address': address,
            'area': area,
        }

    def set_project_info(self, rooms, functions):
        """设置项目信息"""
        self.project_info = {
            'rooms': rooms,
            'functions': functions,
        }

    def add_product(self, name, brand, model, quantity, unit_price, location='', notes=''):
        """添加产品"""
        subtotal = unit_price * quantity
        self.products.append({
            'name': name,
            'brand': brand,
            'model': model,
            'quantity': quantity,
            'unit_price': unit_price,
            'subtotal': subtotal,
            'location': location,
            'notes': notes,
        })

    def _format_price(self, price):
        """格式化价格"""
        return f'¥{price:,.2f}'

    def _create_header(self):
        """创建报价单头部"""
        # 标题
        title = Paragraph('智能家居系统报价单', self.styles['Title'])
        self.story.append(title)
        self.story.append(Spacer(1, 0.5*cm))

        # 公司和客户信息表
        header_data = [
            ['报价单位', self.company_info['name'], '客户姓名', self.customer_info['name']],
            ['联系电话', self.company_info['phone'], '联系电话', self.customer_info['phone']],
            ['公司地址', self.company_info['address'], '项目地址', self.customer_info['address']],
        ]

        if self.customer_info['area']:
            header_data.append(['微信号', self.company_info['wechat'], '房屋面积', self.customer_info['area']])

        header_table = Table(header_data, colWidths=[4*cm, 5*cm, 3*cm, 5*cm])
        header_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'SimSun'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f0f0f0')),
            ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#f0f0f0')),
        ]))

        self.story.append(header_table)
        self.story.append(Spacer(1, 0.5*cm))

        # 报价日期和有效期
        today = datetime.now().strftime('%Y年%m月%d日')
        expiry = (datetime.now() + timedelta(days=30)).strftime('%Y年%m月%d日')

        date_info = f'报价日期：{today}    报价有效期：至 {expiry}'
        date_para = Paragraph(date_info, self.styles['BodyText'])
        self.story.append(date_para)
        self.story.append(Spacer(1, 0.3*cm))

    def _create_project_overview(self):
        """创建项目概况"""
        self.story.append(Paragraph('一、项目概况', self.styles['SectionTitle']))

        # 房间配置
        if self.project_info['rooms']:
            rooms_text = '房间配置：' + '、'.join([f'{k}×{v}' for k, v in self.project_info['rooms'].items()])
            self.story.append(Paragraph(rooms_text, self.styles['BodyText']))

        # 功能清单
        if self.project_info['functions']:
            functions_text = '功能需求：' + '、'.join(self.project_info['functions'])
            self.story.append(Paragraph(functions_text, self.styles['BodyText']))

        self.story.append(Spacer(1, 0.3*cm))

    def _create_product_table(self):
        """创建产品明细表"""
        self.story.append(Paragraph('二、产品明细', self.styles['SectionTitle']))

        # 表头
        table_data = [['序号', '产品名称', '品牌/型号', '数量', '单价', '小计', '安装位置']]

        # 产品数据
        for i, product in enumerate(self.products, 1):
            row = [
                str(i),
                product['name'],
                f"{product['brand']}\\n{product['model']}",
                str(product['quantity']),
                self._format_price(product['unit_price']),
                self._format_price(product['subtotal']),
                product['location'] or '-'
            ]
            table_data.append(row)

        # 创建表格
        product_table = Table(table_data, colWidths=[0.8*cm, 3.5*cm, 3.5*cm, 1.5*cm, 2*cm, 2*cm, 2.7*cm])
        product_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'SimSun'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a5490')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ALIGN', (3, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f9f9f9')]),
        ]))

        self.story.append(product_table)
        self.story.append(Spacer(1, 0.5*cm))

    def _create_cost_summary(self, installation_rate=0.18, design_fee=0, debug_fee=0, discount=0, discount_rate=0):
        """创建费用汇总"""
        self.story.append(Paragraph('三、费用汇总', self.styles['SectionTitle']))

        # 计算各项费用
        product_total = sum(p['subtotal'] for p in self.products)
        installation_fee = product_total * installation_rate

        if discount_rate > 0:
            discount = (product_total + installation_fee) * discount_rate

        total = product_total + installation_fee + design_fee + debug_fee - discount

        # 费用汇总表
        summary_data = [
            ['费用项目', '金额'],
            ['1. 设备小计', self._format_price(product_total)],
            ['2. 安装调试费', f'{self._format_price(installation_fee)} (设备总价×{installation_rate*100:.0f}%)'],
        ]

        if design_fee > 0:
            summary_data.append(['3. 设计费', self._format_price(design_fee)])

        if debug_fee > 0:
            summary_data.append(['4. 系统调试费', self._format_price(debug_fee)])

        if discount > 0:
            if discount_rate > 0:
                summary_data.append(['5. 优惠金额', f'-{self._format_price(discount)} (折扣{discount_rate*100:.0f}%)'])
            else:
                summary_data.append(['5. 优惠金额', f'-{self._format_price(discount)}'])

        # 总计
        summary_data.append(['=' * 20, '=' * 20])
        summary_data.append(['报价总计', self._format_price(total)])

        summary_table = Table(summary_data, colWidths=[10*cm, 5*cm])
        summary_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'SimHei'),
            ('FONTSIZE', (0, 0), (-1, -2), 11),
            ('FONTSIZE', (-1, -1), (-1, -1), 16),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
            ('GRID', (0, 0), (0, -2), 0.5, colors.grey),
            ('LINEBELOW', (0, -2), (-1, -2), 1, colors.HexColor('#1a5490')),
            ('TEXTCOLOR', (-1, -1), (-1, -1), colors.HexColor('#c00')),
            ('FONTNAME', (-1, -1), (-1, -1), 'SimHei'),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))

        self.story.append(summary_table)
        self.story.append(Spacer(1, 0.5*cm))

        return total

    def _create_service_terms(self):
        """创建服务条款"""
        self.story.append(Paragraph('四、服务条款', self.styles['SectionTitle']))

        terms = [
            f'• 保修期限：设备质保2年，安装工程质保2年',
            f'• 施工周期：合同签订后3-5个工作日（具体根据项目规模）',
            f'• 付款方式：签订合同时支付30%定金，设备到场支付40%，验收合格支付30%尾款',
            f'• 本报价单有效期为30天，过期价格可能调整',
            f'• 最终方案以双方确认的合同为准',
            f'• 如需增减设备或功能，价格相应调整',
        ]

        for term in terms:
            self.story.append(Paragraph(term, self.styles['BodyText']))

        self.story.append(Spacer(1, 1*cm))

    def _create_footer(self):
        """创建页脚"""
        footer_data = [
            [Paragraph('<b>感谢您的信任，期待为您服务！</b>', ParagraphStyle('Footer', fontName='SimHei', fontSize=12, alignment=TA_CENTER))],
            [Paragraph(f'联系电话：{self.company_info["phone"]}    微信号：{self.company_info["wechat"]}',
                      ParagraphStyle('Footer', fontName='SimSun', fontSize=10, alignment=TA_CENTER))],
        ]

        footer_table = Table(footer_data, colWidths=[15*cm])
        footer_table.setStyle(TableStyle([
            ('TOPPADDING', (0, 0), (-1, -1), 20),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ]))

        self.story.append(footer_table)

    def generate(self, installation_rate=0.18, design_fee=0, debug_fee=0, discount=0, discount_rate=0):
        """生成PDF报价单"""
        # 注册字体
        register_fonts()

        # 创建各部分
        self._create_header()
        self._create_project_overview()
        self._create_product_table()
        total = self._create_cost_summary(installation_rate, design_fee, debug_fee, discount, discount_rate)
        self._create_service_terms()
        self._create_footer()

        # 生成PDF
        self.doc.build(self.story)
        print(f'报价单已生成：{self.output_path}')
        print(f'报价总计：{self._format_price(total)}')
        return total


# 示例使用
if __name__ == '__main__':
    # 创建报价单
    quotation = SmartHomeQuotation('sample_quotation.pdf')

    # 设置公司信息
    quotation.set_company_info(
        name='智能家居科技有限公司',
        phone='400-123-4567',
        address='北京市朝阳区科技路88号',
        wechat='smarthome_beijing'
    )

    # 设置客户信息
    quotation.set_customer_info(
        name='张先生',
        phone='138****8888',
        address='北京市海淀区XX小区3号楼2单元1001',
        area='120㎡'
    )

    # 设置项目信息
    quotation.set_project_info(
        rooms={'客厅': 1, '卧室': 3, '厨房': 1, '卫生间': 2},
        functions=['智能照明', '电动窗帘', '安防监控', '环境控制']
    )

    # 添加产品
    quotation.add_product('一键开关', 'Aqara', 'QBKG31LM', 8, 89, '客厅、卧室')
    quotation.add_product('双键开关', 'Aqara', 'QBKG33LM', 4, 119, '客厅、厨房')
    quotation.add_product('人体传感器', 'Aqara', 'RTCGQ11LM', 5, 69, '各房间')
    quotation.add_product('窗帘电机', 'Dooya', 'AT35', 2, 580, '客厅、主卧')
    quotation.add_product('智能门锁', '小米', '智能门锁Pro', 1, 1699, '入户门')
    quotation.add_product('室内摄像头', '小米', '智能摄像机3', 2, 169, '客厅、玄关')
    quotation.add_product('空调伴侣', '小米', 'Ktwhl', 2, 249, '客厅、主卧')
    quotation.add_product('多模网关', 'Aqara', 'ZHWG15LM', 1, 329, '客厅')
    quotation.add_product('智能音箱', '小米', '小爱同学Pro', 2, 499, '客厅、主卧')

    # 生成报价单
    # 安装费率18%，设计费1000，无调试费，折扣5%
    quotation.generate(
        installation_rate=0.18,
        design_fee=1000,
        debug_fee=0,
        discount_rate=0.05
    )
